const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();

const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'pages', 'index.html'));
});

app.get('/produtoA', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'pages', 'produtoA.html'));
});

app.get('/produtoB', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'pages', 'produtoB.html'));
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});